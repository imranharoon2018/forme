﻿=== Book Reviews === 
Contributors: ylefebvre 
Donate link: http://ylefebvre.ca/wordpress-plugins/book-reviews 
Tags: book, reviews 
Requires at least: 4.0
Tested up to: 4.8
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
Create your own book review web site! 
 
== Description == 
 
This plugin lets you add a book review system to your WordPress site. Using custom post types, administrators will be able to create and edit book reviews to be published on your site. 
 
== Installation == 
 
1. Download the plugin 
1. Upload the book-reviews folder to your site's wp-content/plugins directory 
1. Activate the plugin in the WordPress Admin Panel 
1. Start creating new book reviews! 
1. Use the [book-review-list] shortcode to list reviews on a page.
 
== Changelog == 
 
= 1.0 = 
* First version of the plugin. 
 
== Frequently Asked Questions == 
 
There are currently no FAQs at this time. 
 
== Screenshots == 
 
1. The review edition page 