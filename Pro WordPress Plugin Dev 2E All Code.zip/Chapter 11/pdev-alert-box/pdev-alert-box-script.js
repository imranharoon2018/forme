/**
 * Displays an alert box with our first translated message when called.
 */
function pdev_show_alert_box_1() {
    alert( pdev_alert_box_L10n.pdev_box_1 );
}
             
/**
 * Displays an alert box with our second translated message when called.
 */
function pdev_show_alert_box_2() {
    alert( pdev_alert_box_L10n.pdev_box_2 );
}
