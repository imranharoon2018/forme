<?php

namespace PDEV;

class Deactivation {

	public static function deactivate() {
		// Run your deactivation code here.
	}
}
